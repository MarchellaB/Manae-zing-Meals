# MaNae's Cuisine Website - Enhanced with Order System

This is a complete website copy of MaNae's Cuisine from Go High Level, converted to work on any free web hosting service, now enhanced with a comprehensive meal ordering system.

## Files Included

- `index.html` - Main HTML file with the website structure
- `order_meals.html` - New meal ordering page with carousel and cart functionality
- `checkout.html` - Checkout page with PayPal integration ready
- `confirmation.html` - Order confirmation page
- `style.css` - Complete CSS styling with responsive design
- `script.js` - JavaScript for interactive functionality
- `images/` - Folder containing all website images (including 23 meal photos)
- `README.md` - This instruction file

## New Features Added

### 🍽️ Order Weekly Meals System
- **Dynamic Meal Carousel**: Browse through 23 different meal options with left/right navigation
- **Quantity Selection**: +/- buttons and direct input for meal quantities
- **Real-time Cart**: Live updating cart with itemized totals
- **Professional Checkout**: Complete checkout flow with customer information forms
- **PayPal Integration**: Ready-to-use PayPal payment processing (requires setup)
- **Order Confirmation**: Professional confirmation page with order details

### 🎨 Enhanced Design Features
- Fully responsive design (works on desktop, tablet, and mobile)
- Interactive navigation with smooth scrolling
- Service buttons with hover effects
- Image galleries with animations
- Professional styling matching the original design
- Mobile-friendly navigation menu
- Scroll-to-top button

### 📱 Easy Management
- **Meal Management**: Easily add/remove meals by updating the meals array in `order_meals.html`
- **Price Updates**: Simple price changes in the JavaScript configuration
- **Image Updates**: Replace meal images in the `images/` folder (meal_1.jpg through meal_23.jpg)

## How to Deploy

### Option 1: Free Hosting Services (Recommended)

1. **Netlify** (netlify.com):
   - Drag and drop all files to Netlify
   - Your site will be live instantly with a free subdomain

2. **Vercel** (vercel.com):
   - Upload files or connect via GitHub
   - Free hosting with custom domains

3. **GitHub Pages**:
   - Create a GitHub repository
   - Upload all files
   - Enable GitHub Pages in repository settings

4. **Firebase Hosting**:
   - Upload files to Firebase
   - Free hosting with Google's infrastructure

### Option 2: Traditional Web Hosting

1. Upload all files to your web hosting provider's public_html or www folder
2. Ensure the folder structure is maintained:
   ```
   /
   ├── index.html
   ├── order_meals.html
   ├── checkout.html
   ├── confirmation.html
   ├── style.css
   ├── script.js
   ├── images/
   │   ├── [original website images]
   │   ├── meal_1.jpg through meal_23.jpg
   └── README.md
   ```

## Setting Up PayPal Integration

To enable real payment processing:

1. **Sign up for PayPal Developer Account**:
   - Go to https://developer.paypal.com/
   - Create a developer account

2. **Create a New App**:
   - Create a new app in your PayPal developer dashboard
   - Get your Client ID

3. **Update the Code**:
   - In `checkout.html`, replace `YOUR_PAYPAL_CLIENT_ID` with your actual Client ID
   - Uncomment the `initializePayPal()` function call

4. **Test the Integration**:
   - Use PayPal's sandbox for testing
   - Switch to live mode when ready for production

## Customization

### Updating Meals
1. **Add New Meals**:
   - Add new images to the `images/` folder (name them meal_24.jpg, meal_25.jpg, etc.)
   - Update the `meals` array in `order_meals.html`

2. **Remove Meals**:
   - Remove entries from the `meals` array
   - Delete corresponding image files

3. **Update Prices**:
   - Modify the `price` values in the `meals` array

### Changing Content
- Edit `index.html` to modify text content
- Replace images in the `images/` folder (keep the same filenames)
- Update contact information and phone numbers

### Styling Changes
- Modify `style.css` to change colors, fonts, or layout
- The CSS uses modern features with responsive design

### Adding Functionality
- Edit `script.js` to add new interactive features
- Current booking buttons show an alert - replace with actual booking system

## Browser Compatibility

- Chrome (recommended)
- Firefox
- Safari
- Edge
- Mobile browsers

## Technical Notes

- All images are optimized for web
- CSS includes modern features with fallbacks
- JavaScript uses vanilla JS (no external dependencies)
- Fully self-contained (no external CDN dependencies except PayPal SDK)
- LocalStorage used for cart persistence

## Order System Features

### For Customers:
- Browse meals with high-quality photos
- Select quantities for each meal
- View real-time cart totals
- Complete secure checkout with PayPal
- Receive order confirmation

### For Business Owner:
- Easy meal management through code updates
- Flexible pricing system
- Professional checkout experience
- Order tracking capabilities
- Customer information collection

## Support

This website includes:
- Complete meal ordering system
- PayPal payment integration (setup required)
- Customer information collection
- Order confirmation system

For advanced features like:
- Database integration
- Email notifications
- Inventory management
- Admin dashboard

You'll need to integrate with appropriate backend services.

## Original Source

Enhanced version of website copied from: https://app.gohighlevel.com/v2/preview/cv5wP1ACqAXi6R44I3u3?notrack=true
Date: July 1, 2025
Enhanced with: Complete meal ordering system with 23 meal options and PayPal integration
